﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PCampeonato
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnexecutar_Click(object sender, EventArgs e)
        {
            string auxiliar1, auxiliar2;
            string[] Mgols = new string[10];
            int N = 10, golsF, golsR, saldo, totalF = 0, totalR = 0;

            listTimes.Items.Clear();

            /*ra = Interaction.InputBox("Digite o ultimo número do seu RA: ", "Entrada de dados");

             if (Int32.TryParse(ra, out N))
             {
                 if (N == 0)
                 {
                     N = 10;
                 }
             */

            for (int i = 0; i < N; i++)
            {
                saldo = 0;
                auxiliar1 = Interaction.InputBox("Gols feitos", "Entrada de dados");
                if (!int.TryParse(auxiliar1, out golsF))
                {
                    MessageBox.Show("Dado invalido");
                    i--;
                }
                auxiliar2 = Interaction.InputBox("Gols recebidos", "Entrada de dados");
                if (!int.TryParse(auxiliar2, out golsR))
                {
                    MessageBox.Show("Dado invalido");
                    i--;
                }

                saldo = golsF - golsR;
                totalF += golsF;
                totalR += golsR;


                Mgols[i] = "Time: " + (i + 1) + " Gols feitos: " + golsF + " Gols recebidos: " + golsR + " Saldo de gols: " + saldo;
            }

            for(int i=0; i< 10; i++)
            {
                listTimes.Items.Add(Mgols[i] + "\n");
            }

            listTimes.Items.Add("----------------------------------------------------------");
            listTimes.Items.Add("Total gols feitos: " + totalF +"\n");
            listTimes.Items.Add("Total gols recebidos: " + totalR + "\n");




        }
    }
}
