﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;


namespace pCopa00302211040
{
    class Jogo
    {
        //propriedades
        public int Id { get; set; }
        public int EstadioId { get; set; }
        public int PaisId1 { get; set; }
        public int PaisId2 { get; set; }
        public DateTime Datahora { get; set; }

        public string Observacao { get; set; }

        public DataTable Listar()
        {
            SqlDataAdapter dajogo;

            DataTable dtjogo = new DataTable();

            try
            {
                dajogo = new SqlDataAdapter("SELECT * FROM jogo", frmPrincipal.conexao);
                dajogo.Fill(dtjogo);
                dajogo.FillSchema(dtjogo, SchemaType.Source);

            }
            catch (Exception)
            {
                throw;
            }

            return dtjogo;
        }

        public int Excluir() //exclusão
        {
            int nReg = 0;

            try
            {
                SqlCommand mycommand;
                mycommand = new SqlCommand("DELETE FROM JOGO WHERE ID=@id", frmPrincipal.conexao);

                mycommand.Parameters.Add(new SqlParameter("@id", SqlDbType.Int));
                mycommand.Parameters["@id"].Value = Id;

                nReg = mycommand.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            return nReg;
        }

        public int Salvar()
        {
            int retorno = 0;
            try
            {
                SqlCommand mycommand;

                mycommand = new SqlCommand("INSERT INTO JOGO VALUES (@Pais1,@Pais2,@Estadio,@DataHora,@Observacao)", frmPrincipal.conexao);
                mycommand.Parameters.Add(new SqlParameter("@Pais1", SqlDbType.Int));
                mycommand.Parameters.Add(new SqlParameter("@Pais2", SqlDbType.Int));
                mycommand.Parameters.Add(new SqlParameter("@Estadio", SqlDbType.Int));
                mycommand.Parameters.Add(new SqlParameter("@DataHora", SqlDbType.Date));
                mycommand.Parameters.Add(new SqlParameter("@Observacao", SqlDbType.VarChar));


                mycommand.Parameters["@Pais1"].Value = PaisId1;
                mycommand.Parameters["@Pais2"].Value = PaisId2;
                mycommand.Parameters["@Estadio"].Value = EstadioId;
                mycommand.Parameters["@DataHora"].Value = Datahora;
                mycommand.Parameters["@Observacao"].Value = Observacao;

                retorno = mycommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return retorno;
        }


        public int Alterar() // alteração
        {

            int retorno = 0;

            try
            {

                SqlCommand mycommand;

                mycommand = new SqlCommand("UPDATE JOGO SET ESTADIO_ID=@estadio," + " PAIS_ID=@pais1, PAIS_ID2=@pais2, DATAHORA=@datahora, " + "OBSERVACAO=@observacao WHERE ID = @id", frmPrincipal.conexao);

                mycommand.Parameters.Add(new SqlParameter("@id", SqlDbType.Int));

                mycommand.Parameters.Add(new SqlParameter("@estadio", SqlDbType.Int));

                mycommand.Parameters.Add(new SqlParameter("@pais1", SqlDbType.Int));

                mycommand.Parameters.Add(new SqlParameter("@pais2", SqlDbType.Int));

                mycommand.Parameters.Add(new SqlParameter("@datahora", SqlDbType.Date));

                mycommand.Parameters.Add(new SqlParameter("@observacao", SqlDbType.VarChar));

                mycommand.Parameters["@id"].Value = Id;

                mycommand.Parameters["@estadio"].Value = EstadioId;

                mycommand.Parameters["@pais1"].Value = PaisId1;

                mycommand.Parameters["@pais2"].Value = PaisId2;

                mycommand.Parameters["@dataHora"].Value = Datahora;

                mycommand.Parameters["@observacao"].Value = Observacao;

                retorno = mycommand.ExecuteNonQuery();

            }

            catch (Exception)
            {

                throw;

            }

            return retorno;

        }
    }
}