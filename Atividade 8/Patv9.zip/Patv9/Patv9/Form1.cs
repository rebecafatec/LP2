﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Patv9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux;

            for (var i = 0; i < 20; i++)
            {
                aux = Interaction.InputBox("Digite número", "Entrada de dados");

                if (!int.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("Dado inválido");
                    i--;
                }
            }
            aux = "";
            for (var i = 19; i >= 0; i--)
            {
                aux = aux + vetor[i] + "\n";
            }
            MessageBox.Show(aux);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double[] qtd = new double[10];
            double[] vlr = new double[10];
            double faturamento = 0;

            string auxiliar = "";

            for (var i = 0; i < 10; i++)
            {
                auxiliar = Interaction.InputBox("Digite quantidade de mercadoria" + (i + 1), "Entrada de quantidades");

                if (!double.TryParse(auxiliar, out qtd[i]))
                {
                    MessageBox.Show("Quantidade inválida");
                    i--;
                }

                else
                {
                    while (vlr[i] <= 0)
                    {
                        auxiliar = "";

                        auxiliar = Interaction.InputBox("Digite o valor da mercadoria" + (i + 1), "Entrada preços");

                        if (!Double.TryParse(auxiliar, out vlr[i]))
                        {
                            MessageBox.Show("preço inválido");
                        }
                    }

                    faturamento += qtd[i] * vlr[i];
                }
           
            }
            MessageBox.Show(faturamento.ToString("N2"));
        }
    }
}


